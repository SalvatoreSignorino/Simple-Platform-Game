#pragma once
#ifndef PLAYERBALL
#define PLAYERBALL
#include <SFML/Audio.hpp>
#include <iostream>
#include "Circle.hpp"
#define DEF_ACC 7.5f	// Default acceleration.
#define DEF_VEL 12.f	// Default velocity per second.
#define DEF_GRAV 30.f	// Default gravity.


sf::Texture playerTexture;

std::vector<sf::IntRect> textures;



class PlayerBall : public Circle {	// Only one instance can exixt.
public:
	// Movement members.
	sf::Vector2f velocity = { 0.f, 0.f };
	sf::Vector2f acceleration = { 0.f, 0.f };
	float gravity = DEF_GRAV;
	const char LEFT = 'l';
	const char RIGHT = 'r';
	const char JUMP = 'j';
	const char STOP = 's';
	bool aboveGround = true;

	std::vector<sf::IntRect>::iterator texIt;
	sf::Int8 collected;
	sf::SoundBuffer pBuffer[2];
	sf::Sound jumpSound;
	sf::Sound collectSound;

	// Constructor.
	PlayerBall() : Circle(12.f) {
		if (!playerTexture.loadFromFile("texture.png"))	std::cerr << "ERROR loading player texture" << std::endl;

		// debugging
		//setOutlineThickness(2);
		//setOutlineColor(sf::Color::Red);

		textures.push_back(sf::IntRect(0, 0, 15, 16));		//	 0 collected
		textures.push_back(sf::IntRect(49, 0, 15, 16));		//	 1 collected
		textures.push_back(sf::IntRect(464, 0, -15, 16));	//	 2 collected
		textures.push_back(sf::IntRect(80, 0, 15, 16));		//	 3 collected
		textures.push_back(sf::IntRect(432, 0, -15, 16));	//	 4 collected
		textures.push_back(sf::IntRect(416, 0, -15, 16));	//	 5 collected
		textures.push_back(sf::IntRect(145, 0, 15, 16));	//	 6 collected
		textures.push_back(sf::IntRect(384, 0, -15, 16));	//	 7 collected
		textures.push_back(sf::IntRect(177, 0, 15, 16));	//	 8 collected
		textures.push_back(sf::IntRect(352, 0, -15, 16));	//	 9 collected
		textures.push_back(sf::IntRect(272, 0, 15, 16));	//	10 collected

		if (!pBuffer[0].loadFromFile("jump.wav"))	std::cerr << "ERROR loading jump sound" << std::endl;
		jumpSound.setBuffer(pBuffer[0]);
		if (!pBuffer[1].loadFromFile("collect.wav"))	std::cerr << "ERROR loading collect sound" << std::endl;
		collectSound.setBuffer(pBuffer[1]);

		collected = 0;
		texIt = textures.begin();
		setTexture(&playerTexture);
		setTextureRect(*texIt);
		playerTexture.setSmooth(true);
	}


	// Sets acceleration.
	void accelerate(char mode)
	{
		switch (mode)
		{
		case 'l':
			velocity.x = -DEF_VEL / 2.f;
			acceleration.x = -DEF_ACC;
			break;
		case 'r':
			velocity.x = DEF_VEL / 2.f;
			acceleration.x = DEF_ACC;
			break;
		case 'j':
			if (!aboveGround)
			{
				jumpSound.play();
				acceleration.y = -DEF_ACC * 40.f;
			}
			break;
		case 's':
			acceleration.x = 0.f;
			velocity.x = 0.f;
		default:
			break;
		}
	}


	void collect()
	{
		collectSound.play();
		collected++;
		setTextureRect(*(++texIt));
	}
};

#endif // !PLAYERBALL