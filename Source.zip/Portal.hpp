#pragma once

#ifndef ORANGE
#define ORANGE
const sf::Color Orange(255, 128, 0);
#endif


#ifndef PORTAL
#define PORTAL
#include <SFML/Graphics.hpp>


class Portal : public sf::RectangleShape	// Singleton
{
public:
	const sf::Uint8 freq = 15;
	sf::Uint8 colorState = 0;
	sf::Clock colorClock;
	sf::Texture texture;

	
	Portal(const sf::Vector2f& position = sf::Vector2f(0.f, 0.f)) : sf::RectangleShape(sf::Vector2f(30, 40))
	{
		if (!texture.loadFromFile("portal.png"))	std::cerr << "ERROR loading player texture" << std::endl;

		setPosition(position);
	//	setOutlineThickness(4);
	//	setFillColor(sf::Color::White);
	//	setOutlineColor(sf::Color::Yellow);
		setTexture(&texture);
		setTextureRect(sf::IntRect(0, 32, 26, 32));
	}

/*
	void update()
	{
		if (this == nullptr) return;

		if (colorClock.getElapsedTime().asMilliseconds() / FREQ > 1)
		{
			switch (colorState) {
			case 0:
				setFillColor(sf::Color::Yellow);
				setOutlineColor(Orange);
				colorState = 1;
				colorClock.restart();
				break;
			case 1:
				setFillColor(Orange);
				setOutlineColor(sf::Color::White);
				colorState = 2;
				colorClock.restart();
				break;
			case 2:
				setFillColor(sf::Color::White);
				setOutlineColor(sf::Color::Yellow);
				colorState = 0;
				colorClock.restart();
				break;
			default:
				;
			}
		}
	}
*/};

#endif // !PORTAL
