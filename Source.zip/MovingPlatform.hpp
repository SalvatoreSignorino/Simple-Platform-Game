#pragma once
#ifndef MOVING_PLATFORM
#define MOVING_PLATFORM
#include "Platform.hpp"
#define DEF_MOV 5.f

class MovingPlatform : public Platform
{
public:
	bool direction;		// 0 = vertical, 1 = horizontal
	bool going = false;	// If vertical: 0 = down, 1 = up. If horizontal: 0 = right, 1 = left.
	float minPos, maxPos;
	float delta = 0;


	MovingPlatform(bool dir, float min, float max, const sf::Vector2f& size = sf::Vector2f(0.f, 0.f)) : Platform(size)
	{
		direction = dir;
		minPos = min;
		maxPos = max;

	}
	
	void update(float deltaTime)
	{
		delta = deltaTime;

		if (direction)	// Horizontal
		{
			if (going)	// Going left
			{
				if (getPosition().x >= minPos)
				{
					move(-DEF_MOV * deltaTime * 60.f, 0.f);
				}
				else
					going = false;	// Start moving right.
			}
			else    // Going right
			{
				if (getPosition().x <= maxPos)
				{
					move(DEF_MOV * deltaTime * 60.f, 0.f);
				}
				else
				{
					going = true;
				}
			}
		}
		else
		{
			if (going)	// Going up
			{
				if (getPosition().y >= minPos)
				{
					move(0.f, -DEF_MOV * deltaTime * 60.f);
				}
				else
				{
					going = false;	// Start moving up.
				}
			}
			else    // Going down
			{
				if (getPosition().y <= maxPos)
				{
					move(0.f, DEF_MOV * deltaTime * 60.f);
				}
				else
				{
					going = true;
				}
			}
		}
	}

	void moveWith(PlayerBall& player) {
		if (direction)	// Horizontal
		{
			if (going)	// Going left
			{
				if (getPosition().x >= minPos)
				{
					player.move(-DEF_MOV * delta * 60.f, 0.f);
				}
					// Start moving right.
			}
			else    // Going right
			{
				if (getPosition().x <= maxPos)
				{
					player.move(DEF_MOV * delta * 60.f, 0.f);
				}
			}
		}
		else
		{
			if (going)	// Going up
			{
				if (getPosition().y >= minPos)
				{
					//player.move(0.f, -1-DEF_MOV * delta * 60.f);
				}
			}
			else    // Going down
			{
				if (getPosition().y <= maxPos)
				{
					player.move(0.f, 2+DEF_MOV * delta * 60.f); 
				}
			}
		}
	}
};


#endif // !MOVING_PLATFORM
