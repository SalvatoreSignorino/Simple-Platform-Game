#pragma once
#ifndef LEVELOBJECT
#define LEVELOBJECT
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include "MovingPlatform.hpp"
#include "Portal.hpp"
using namespace std;
using namespace sf;


Vector2f vec(136.f, 40.f);
Vector2f altVec(40.f, 136.f);


class LevelObject {	// Singleton
public:
	Uint8 levelNum;
	vector<RectangleShape> rectanglesRed;
	vector<RectangleShape> rectanglesGreen;
	vector<RectangleShape> rectanglesBlue;
	vector<RectangleShape> rectanglesWhite;
	vector<Platform*> platformsWhite;
	vector<Platform*> platformsRed;
	vector<Platform*> platformsBlue;
	vector<Platform*> platformsGreen;

	Texture rectRedTexture;
	Texture rectGreenTexture;
	Texture rectBlueTexture;
	Texture rectWhiteTexture;
	Texture platRedTexture;
	Texture platGreenTexture;
	Texture platBlueTexture;
	Texture platWhiteTexture;

	short rgb = 0;
	PlayerBall player;
	Portal* portal = nullptr;
	std::vector<Collectable> collectables;
	Sprite background;
	Texture backTexture;
	SoundBuffer fBuffer[2];
	Sound fallSound;
	Sound colorSound;
	Music bgMusic;


	LevelObject(Uint8 levelNum) : levelNum(levelNum)
	{
		// Loaing textures
		if (!rectRedTexture.loadFromFile("redRect.png"))	std::cerr << "ERROR loading red boxes texture" << std::endl;
		if (!rectBlueTexture.loadFromFile("blueRect.png"))	std::cerr << "ERROR loading blue boxes texture" << std::endl;
		if (!rectGreenTexture.loadFromFile("greenRect.png"))	std::cerr << "ERROR loading green boxes texture" << std::endl;
		if (!rectWhiteTexture.loadFromFile("whiteRect.png"))	std::cerr << "ERROR loading white boxes texture" << std::endl;
		
		rectRedTexture.setRepeated(true);
		rectBlueTexture.setRepeated(true);
		rectGreenTexture.setRepeated(true);
		rectWhiteTexture.setRepeated(true);

		if (!fBuffer[0].loadFromFile("fall.wav"))	std::cerr << "ERROR loading fall sound" << std::endl;
		fallSound.setBuffer(fBuffer[1]);
		fallSound.setVolume(80);
		if (!fBuffer[1].loadFromFile("color.wav"))	std::cerr << "ERROR loading color sound" << std::endl;
		colorSound.setBuffer(fBuffer[1]);

		collectables = createCollectables(levelNum);

		if (levelNum == 1)
		{
			if (!bgMusic.openFromFile("Level1_Theme.wav"))	std::cerr << "ERROR loading background music" << std::endl;
			if (!platWhiteTexture.loadFromFile("platWhite.png"))	std::cerr << "ERROR loading white plats texture" << std::endl;
			if (!backTexture.loadFromFile("background1.png"))	std::cerr << "ERROR loading background texture" << std::endl;
			background.setTexture(backTexture);
			bgMusic.setLoop(true);
			bgMusic.play();

			// Red Rectangles
			{
				rectanglesRed.push_back(RectangleShape(Vector2f(40.f, 120.f)));
				rectanglesRed[0].setPosition(166.f, 617.f);

				rectanglesRed.push_back(RectangleShape(vec));
				rectanglesRed[1].setPosition(826.f, 288.f);

				rectanglesRed.push_back(RectangleShape(Vector2f(102.f, 40.f)));
				rectanglesRed[2].setPosition(1098.f, 288.f);

				rectanglesRed.push_back(RectangleShape(Vector2f(136.f, 20.f)));
				rectanglesRed[3].setPosition(1016.f, 144.f);

				for (vector<RectangleShape>::iterator it = rectanglesRed.begin(); it != rectanglesRed.end(); it++)
				{
					it->setTexture(&rectRedTexture);
					it->setTextureRect(IntRect(0, 0, it->getSize().x, it->getSize().y));
				}
			}

			// Blue Rectangles
			{
				rectanglesBlue.push_back(RectangleShape(Vector2f(40.f, 102.f)));
				rectanglesBlue[0].setPosition(550.f, 644.f);

				rectanglesBlue.push_back(RectangleShape(Vector2f(20.f, 168.f)));
				rectanglesBlue[1].setPosition(1036.f, 328.f);

				rectanglesBlue.push_back(RectangleShape(vec));
				rectanglesBlue[2].setPosition(900.f, 456.f);

				rectanglesBlue.push_back(RectangleShape(vec));
				rectanglesBlue[3].setPosition(962.f, 288.f);

				rectanglesBlue.push_back(RectangleShape(Vector2f(136.f, 20.f)));
				rectanglesBlue[4].setPosition(320.f, 144.f);

				for (vector<RectangleShape>::iterator it = rectanglesBlue.begin(); it != rectanglesBlue.end(); it++)
				{
					it->setTexture(&rectBlueTexture);
					it->setTextureRect(IntRect(0, 0, it->getSize().x, it->getSize().y));
				}
			}

			// Green Rectangles
			{
				rectanglesGreen.push_back(RectangleShape(vec));
				rectanglesGreen[0].setPosition(320.f, 696.f);

				rectanglesGreen.push_back(RectangleShape(vec));
				rectanglesGreen[1].setPosition(680.f, 456.f);

				rectanglesGreen.push_back(RectangleShape(vec));
				rectanglesGreen[2].setPosition(240.f, 288.f);

				rectanglesGreen.push_back(RectangleShape(Vector2f(136.f, 20.f)));
				rectanglesGreen[3].setPosition(800.f, 144.f);

				rectanglesGreen.push_back(RectangleShape(Vector2f(102.f, 20.f)));
				rectanglesGreen[4].setPosition(240.f, 74.f);

				for (vector<RectangleShape>::iterator it = rectanglesGreen.begin(); it != rectanglesGreen.end(); it++)
				{
					it->setTexture(&rectGreenTexture);
					it->setTextureRect(IntRect(0, 0, it->getSize().x, it->getSize().y));
				}
			}

			// White Rectangles
			{
				rectanglesWhite.push_back(RectangleShape(vec));
				rectanglesWhite[0].setPosition(30.f, 696.f);

				rectanglesWhite.push_back(RectangleShape(Vector2f(40.f, 168.f)));
				rectanglesWhite[1].setPosition(590.f, 576.f);

				rectanglesWhite.push_back(RectangleShape(vec));
				rectanglesWhite[2].setPosition(240.f, 360.f);

				rectanglesWhite.push_back(RectangleShape(Vector2f(102.f, 40.f)));
				rectanglesWhite[3].setPosition(80.f, 288.f);

				rectanglesWhite.push_back(RectangleShape(vec));
				rectanglesWhite[4].setPosition(1200.f, 288.f);

				rectanglesWhite.push_back(RectangleShape(Vector2f(102.f, 20.f)));
				rectanglesWhite[5].setPosition(1152.f, 202.f);

				rectanglesWhite.push_back(RectangleShape(vec));
				rectanglesWhite[6].setPosition(120.f, 120.f);


				for (vector<RectangleShape>::iterator it = rectanglesWhite.begin(); it != rectanglesWhite.end(); it++)
				{
					it->setTexture(&rectWhiteTexture);
					it->setTextureRect(IntRect(0, 0, it->getSize().x, it->getSize().y));
				}
			}

			// White Platforms
			{
				Vector2f size(50.f, 5.f);
				platformsWhite.push_back(new MovingPlatform(false, 350, 696, size));
				platformsWhite.push_back(new MovingPlatform(true, 500, 750, size));
				platformsWhite.push_back(new MovingPlatform(true, 500, 730, size));
				platformsWhite.push_back(new MovingPlatform(true, 400, 1190, size));
				platformsWhite.push_back(new Platform(size));
				
				platformsWhite[0]->setPosition(1140.f, 696.f);	// Moving, vertical
				platformsWhite[1]->setPosition(500.f, 312.f);	// Moving, horizontal
				platformsWhite[2]->setPosition(730.f, 168.f);	// Moving, horizontal
				platformsWhite[3]->setPosition(400.f, 72.f);	// Moving, horizontal
				platformsWhite[4]->setPosition(850.f, 696.f);	// Still

				for (vector<Platform*>::iterator it = platformsWhite.begin(); it != platformsWhite.end(); it++)
				{
					(*it)->setTexture(&platWhiteTexture);
					(*it)->setTextureRect(IntRect(0, 0, 200, 20));
				}
			}
		
			player.setPosition(rectanglesWhite[0].getPosition().x + (rectanglesWhite[0].getSize().x/2), rectanglesWhite[0].getPosition().y - player.getRadius()-100);
			
			portal = new Portal(sf::Vector2f(860, 656));
		}
		if (levelNum == 2) {
			Vector2f rectangleShape(26.f, 26.f);
			Vector2f platformShape(26.f, 5.f);
			if (!bgMusic.openFromFile("Level2_Theme.ogg"))	std::cerr << "ERROR loading background music" << std::endl;
			if (!backTexture.loadFromFile("background2.png"))	std::cerr << "ERROR loading background texture" << std::endl;
			background.setTexture(backTexture);
			bgMusic.setLoop(true);
			bgMusic.play();

			if (!platWhiteTexture.loadFromFile("smallWhite.png"))	std::cerr << "ERROR loading white plats texture" << std::endl;
			if (!platRedTexture.loadFromFile("smallRed.png"))	std::cerr << "ERROR loading red plats texture" << std::endl;
			if (!platBlueTexture.loadFromFile("smallBlue.png"))	std::cerr << "ERROR loading blue plats texture" << std::endl;
			if (!platGreenTexture.loadFromFile("smallGreen.png"))	std::cerr << "ERROR loading green plats texture" << std::endl;

			//Red Rectangles
			{
				for (int i = 0; i < 5; i++) {
					RectangleShape tmp(rectangleShape);
					tmp.setTexture(&rectRedTexture);
					tmp.setTextureRect(IntRect(0, 0, 70, 70));
					rectanglesRed.push_back(tmp);
				}

				rectanglesRed[0].setPosition(280.f, 696.f);
				rectanglesRed[1].setPosition(940.f, 696.f);
				rectanglesRed[2].setPosition(380.f, 432.f);
				rectanglesRed[3].setPosition(1300.f, 432.f);
				rectanglesRed[4].setPosition(1140.f, 41.f);
			}

			//Blue Rectangles
			{
				for (int i = 0; i < 5; i++) {
					RectangleShape tmp(rectangleShape);
					tmp.setTexture(&rectBlueTexture);
					tmp.setTextureRect(IntRect(0, 0, 70, 70));
					rectanglesBlue.push_back(tmp);
				}
				rectanglesBlue[0].setPosition(900.f, 432.f);
				rectanglesBlue[1].setPosition(920.f, 210.f);
				rectanglesBlue[2].setPosition(1320.f, 225.f);
				rectanglesBlue[3].setPosition(1060.f, 81.f);
				rectanglesBlue[4].setPosition(160.f, 72.f);
			}

			//Green Rectangles
			{
				for (int i = 0; i < 5; i++) {
					RectangleShape tmp(rectangleShape);
					tmp.setTexture(&rectGreenTexture);
					tmp.setTextureRect(IntRect(0, 0, 70, 70));
					rectanglesGreen.push_back(tmp);
				}

				rectanglesGreen[0].setPosition(600.f, 552.f);
				rectanglesGreen[1].setPosition(160.f, 432.f);
				rectanglesGreen[2].setPosition(740.f, 192.f);
				rectanglesGreen[3].setPosition(720.f, 72.f);
				rectanglesGreen[4].setPosition(1260.f, 36.f);
			}

			//White Rectangles
			{
				for (int i = 0; i < 6; i++) {
					RectangleShape tmp(rectangleShape);
					tmp.setTexture(&rectWhiteTexture);
					tmp.setTextureRect(IntRect(0, 0, 70, 70));
					rectanglesWhite.push_back(tmp);
				}

				rectanglesWhite[0].setPosition(120.f, 696.f);
				rectanglesWhite[1].setPosition(40.f, 384.f);
				rectanglesWhite[2].setPosition(540.f, 384.f);
				rectanglesWhite[3].setPosition(380.f, 164.f);
				rectanglesWhite[4].setPosition(1020.f, 164.f);
				rectanglesWhite[5].setPosition(820.f, 72.f);
			}

			//White Platforms
			{
				MovingPlatform* tmp = new MovingPlatform(false, 433, 696, platformShape);
				tmp->setPosition(1086.f, 696.f);
				tmp->setTexture(&platWhiteTexture);
				tmp->setTextureRect(IntRect(0, 0, 100, 20));
				platformsWhite.push_back(tmp);
			}

			//Red Platforms
			{
				platformsRed.push_back(new Platform(platformShape));
				platformsRed.push_back(new Platform(platformShape));
				platformsRed.push_back(new MovingPlatform(true, 600, 830, platformShape));
				platformsRed.push_back(new Platform(platformShape));
				platformsRed.push_back(new MovingPlatform(true, 250, 650, platformShape));
				for (int i = 0; i < 5; i++) {
					platformsRed[i]->setTexture(&platRedTexture);
					platformsRed[i]->setTextureRect(IntRect(0, 0, 100, 20));
				}

				platformsRed[0]->setPosition(700.f, 444.f);
				platformsRed[1]->setPosition(120.f, 276.f);
				platformsRed[2]->setPosition(600.f, 276.f);
				platformsRed[3]->setPosition(1180.f, 228.f);
				platformsRed[4]->setPosition(650.f, 84.f);
			}

			//Blue Platforms
			{
				MovingPlatform* tmp = new MovingPlatform(true, 400, 840, platformShape);
				tmp->setPosition(1086.f, 696.f);
				tmp->setTexture(&platBlueTexture);
				tmp->setTextureRect(IntRect(0, 0, 100, 20));	
				tmp->setPosition(400.f, 696.f);
				platformsBlue.push_back(tmp);
			}

			//Green Platforms
			{
				platformsGreen.push_back(new Platform(platformShape));				
				platformsGreen.push_back(new MovingPlatform(true, 260, 440, platformShape));
				for (int i = 0; i < 2; i++) {
					platformsGreen[i]->setTexture(&platGreenTexture);
					platformsGreen[i]->setTextureRect(IntRect(0, 0, 100, 20));
				}

				platformsGreen[0]->setPosition(780.f, 444.f);
				platformsGreen[1]->setPosition(260.f, 276.f);
			}

			player.setPosition(rectanglesWhite[0].getPosition().x + (rectanglesWhite[0].getSize().x/2), rectanglesWhite[0].getPosition().y - player.getRadius() - 20);

			portal = new Portal(sf::Vector2f(1017.f, 124.f));
		}
	}


	~LevelObject() {
		clear();
	}


	void changeColor(Uint8 color)
	{
		if (rgb != color)
		{
			colorSound.play();
			rgb = color;
		}
	}


	void clear()
	{
		bgMusic.stop();
		vector<RectangleShape>().swap(rectanglesRed);
		vector<RectangleShape>().swap(rectanglesGreen);
		vector<RectangleShape>().swap(rectanglesBlue);
		vector<RectangleShape>().swap(rectanglesWhite);

		for (vector<Platform*>::iterator it = platformsWhite.begin(); it != platformsWhite.end(); it++)
		{
			delete* it;
		}

		vector<Platform*>().swap(platformsWhite);
	}


	void draw(RenderWindow& window) {
		
		window.draw(background);

		for (vector<RectangleShape>::iterator i = rectanglesWhite.begin(); i != rectanglesWhite.end(); i++) {
			window.draw(*i);
		}

		for (vector<Platform*>::iterator i = platformsWhite.begin(); i != platformsWhite.end(); i++)
		{
			window.draw(**i);
		}

		if (rgb == 1) {
			for (vector<RectangleShape>::iterator i = rectanglesRed.begin(); i != rectanglesRed.end(); i++) {
				window.draw(*i);
			}


			if (platformsRed.size() != 0)
				for (vector<Platform*>::iterator i = platformsRed.begin(); i != platformsRed.end(); i++)
				{
					window.draw(**i);
				}
		}

		if (rgb == 2) {
			for (vector<RectangleShape>::iterator i = rectanglesGreen.begin(); i != rectanglesGreen.end(); i++) {
				window.draw(*i);
			}


			if (platformsGreen.size() != 0)
				for (vector<Platform*>::iterator i = platformsGreen.begin(); i != platformsGreen.end(); i++)
				{
					window.draw(**i);
				}
		}
		
		if (rgb == 3) {
			for (vector<RectangleShape>::iterator i = rectanglesBlue.begin(); i != rectanglesBlue.end(); i++) {
				window.draw(*i);
			}


			if (platformsBlue.size() != 0)
				for (vector<Platform*>::iterator i = platformsBlue.begin(); i != platformsBlue.end(); i++)
				{
					window.draw(**i);
				}
		}

		if (portal != nullptr) window.draw(*portal);
		drawCollectables(collectables, window);
		window.draw(player);
	}


	void update(float deltaTime, sf::Vector2u wSize)
	{
		player.aboveGround = true;

		player.velocity += player.acceleration * deltaTime;	// Updates velocity in function of acceleration:	v = v_0 + a*t

		// Velocity in each direction must not be higher than default.
		if (player.velocity.x > DEF_VEL)	player.velocity.x = DEF_VEL;
		if (player.velocity.x < -DEF_VEL)	player.velocity.x = -DEF_VEL;
		if (player.velocity.y > DEF_VEL * 2.f)	player.velocity.y = DEF_VEL * 2.f;
		if (player.velocity.y < -DEF_VEL)	player.velocity.y = -DEF_VEL;


		// Handle collisions with window's boundaries.
		{
			if (player.getPosition().x - player.getRadius() <= 0 && player.velocity.x < 0)	// left window edge
			{
				player.setPosition(player.getRadius(), player.getPosition().y);
				player.velocity.x = 0;
			}
			if (player.getPosition().x + player.getRadius() >= wSize.x && player.velocity.x > 0)	// right window edge
			{
				player.setPosition(wSize.x - player.getRadius(), player.getPosition().y);
				player.velocity.x = 0;
			}
			if (player.getPosition().y - player.getRadius() < 0 && player.velocity.y < 0)	// top of window
			{
				player.setPosition(player.getPosition().x, player.getRadius());
				player.velocity.y = 0;
			}
			if (player.getPosition().y + player.getRadius() > wSize.y&& player.velocity.y > 0)	// bottom of window
			{
				fallSound.play();
				player.setPosition(rectanglesWhite[0].getPosition().x + (rectanglesWhite[0].getSize().x/2), rectanglesWhite[0].getPosition().y - player.getRadius());
				player.velocity.y = 0;
				player.aboveGround = false;
			}
		}

		// Handle collisions with platforms.
		resolveCollisions(rectanglesWhite);
		resolveCollisions(platformsWhite);
		switch (rgb)
		{
		case 1:
			resolveCollisions(rectanglesRed);
			if (platformsRed.size() != 0) 	resolveCollisions(platformsRed);
			break;
		case 2:
			resolveCollisions(rectanglesGreen);
			if (platformsGreen.size() != 0) 	resolveCollisions(platformsGreen); 
			break;
		case 3:
			resolveCollisions(rectanglesBlue);
			if (platformsBlue.size() != 0) 	resolveCollisions(platformsBlue);
			break;
		default:
			break;
		}

		// Set gravity
		if (player.aboveGround)
			player.acceleration.y = player.gravity = DEF_GRAV;
		else
			player.gravity = 0;

		player.move(player.velocity * 60.f * deltaTime);
		player.rotate(player.velocity.x * 60.f * 3.1415 * deltaTime);	// Rotation must depend only on horizontal movement, if there actually is one.

		updateCollectables(collectables, deltaTime);

		updatePlatforms(deltaTime);

		// Collecting a triangle.
		for (std::vector<Collectable>::iterator it = collectables.begin(); collectables.size() > 0 && it != collectables.end(); it++)
		{
			if (player.getGlobalBounds().intersects(it->getGlobalBounds()))
			{
				collectables.erase(it);
				if (it == collectables.end()) it--;
				player.collect();
				if (player.collected == 10) portal->setTextureRect(IntRect(0, 0, 26, 32));
			}
		}
	}


	void updatePlatforms(float deltaTime) {
		for (vector<Platform*>::iterator it = platformsWhite.begin(); it != platformsWhite.end(); it++)
		{
			(*it)->update(deltaTime);
		}

		if (platformsRed.size() != 0) {
			for (vector<Platform*>::iterator itr = platformsRed.begin(); itr != platformsRed.end(); itr++) {
				(*itr)->update(deltaTime);
			}
		}

		if (platformsGreen.size() != 0) {
			for (vector<Platform*>::iterator itr = platformsGreen.begin(); itr != platformsGreen.end(); itr++) {
				(*itr)->update(deltaTime);
			}
		}

		if (platformsBlue.size() != 0) {
			for (vector<Platform*>::iterator itr = platformsBlue.begin(); itr != platformsBlue.end(); itr++) {
				(*itr)->update(deltaTime);
			}
		}
	}


	void resolveCollisions(vector<RectangleShape>& v)
	{
		for (vector<RectangleShape>::iterator it = v.begin(); it != v.end(); it++)
		{
			if (player.getGlobalBounds().intersects(it->getGlobalBounds()))
			{
				// Bottom collision
				if (player.getPosition().y - player.getRadius() <= it->getPosition().y &&
					player.getPosition().y + player.getRadius() >= it->getPosition().y &&
					player.getPosition().x + player.getRadius() >= it->getPosition().x &&
					player.getPosition().x - player.getRadius() <= it->getPosition().x + it->getSize().x) {
					if (player.velocity.y > 0)
					{
						player.velocity.y = 0;
						player.setPosition(player.getPosition().x, it->getPosition().y - player.getRadius());
					}
					player.aboveGround = false;
				}
				else
					// Top collision
					if (player.getPosition().y - player.getRadius() <= it->getPosition().y + it->getSize().y &&
						player.getPosition().y + player.getRadius() >= it->getPosition().y + it->getSize().y &&
						player.getPosition().x + player.getRadius() >= it->getPosition().x &&
						player.getPosition().x - player.getRadius() <= it->getPosition().x + it->getSize().x)
					{
						if (player.velocity.y < 0)
						{
							player.velocity.y = 0;
							player.setPosition(player.getPosition().x, it->getPosition().y + it->getSize().y + player.getRadius());
						}
					}
					else
						// Left collision
						if (player.getPosition().x + player.getRadius() >= it->getPosition().x &&
							player.getPosition().x - player.getRadius() <= it->getPosition().x &&
							player.getPosition().y + player.getRadius() >= it->getPosition().y &&
							player.getPosition().y - player.getRadius() <= it->getPosition().y + it->getSize().y)
						{
							if (player.velocity.x > 0 || player.acceleration.x > 0)
							{
								player.accelerate(player.STOP);
								player.velocity.x = 0;
								player.setPosition(it->getPosition().x - player.getRadius(), player.getPosition().y);
							}
						}
						else
							// Right collision
							if (player.getPosition().x - player.getRadius() <= it->getPosition().x + it->getSize().x &&
								player.getPosition().x + player.getRadius() >= it->getPosition().x + it->getSize().x &&
								player.getPosition().y + player.getRadius() >= it->getPosition().y &&
								player.getPosition().y - player.getRadius() <= it->getPosition().y + it->getSize().y)
							{
								if (player.velocity.x < 0)
								{
									player.accelerate(player.STOP);
									player.velocity.x = 0;
									player.setPosition(it->getPosition().x + it->getSize().x + player.getRadius(), player.getPosition().y);
								}
							}
							else
								// Compenetration
								if (it->getGlobalBounds().contains(player.getPosition()))
								{
									player.acceleration = Vector2f(0.f, 0.f);
									player.velocity = Vector2f(0.f, 0.f);
								}
			}
		}
	}


	void resolveCollisions(vector<Platform*>& v)
	{
		for (vector<Platform*>::iterator it = v.begin(); it != v.end(); it++)
		{
			if (player.getGlobalBounds().intersects((*it)->getGlobalBounds()))
			{
				// Bottom collision
				if (player.getPosition().y - player.getRadius() <= (*it)->getPosition().y &&
					player.getPosition().y + player.getRadius() >= (*it)->getPosition().y &&
					player.getPosition().x + player.getRadius() >= (*it)->getPosition().x &&
					player.getPosition().x - player.getRadius() <= (*it)->getPosition().x + (*it)->getSize().x) {
					if (player.velocity.y > 0)
					{
						player.velocity.y = 0;
						player.setPosition(player.getPosition().x, (*it)->getPosition().y - player.getRadius());
						(*it)->moveWith(player);
					}
					player.aboveGround = false;
				}
				else
					// Top collision
					if (player.getPosition().y - player.getRadius() <= (*it)->getPosition().y + (*it)->getSize().y &&
						player.getPosition().y + player.getRadius() >= (*it)->getPosition().y + (*it)->getSize().y &&
						player.getPosition().x + player.getRadius() >= (*it)->getPosition().x &&
						player.getPosition().x - player.getRadius() <= (*it)->getPosition().x + (*it)->getSize().x)
					{
						if (player.velocity.y < 0)
						{
							player.velocity.y = 0;
							player.setPosition(player.getPosition().x, (*it)->getPosition().y + (*it)->getSize().y + player.getRadius());
						}
					}
					else
						// Left collision
						if (player.getPosition().x + player.getRadius() >= (*it)->getPosition().x &&
							player.getPosition().x - player.getRadius() <= (*it)->getPosition().x &&
							player.getPosition().y + player.getRadius() >= (*it)->getPosition().y &&
							player.getPosition().y - player.getRadius() <= (*it)->getPosition().y + (*it)->getSize().y)
						{
							if (player.velocity.x > 0 || player.acceleration.x > 0)
							{
								player.accelerate(player.STOP);
								player.velocity.x = 0;
								player.setPosition((*it)->getPosition().x - player.getRadius(), player.getPosition().y);
							}
						}
						else
							// Right collision
							if (player.getPosition().x - player.getRadius() <= (*it)->getPosition().x + (*it)->getSize().x &&
								player.getPosition().x + player.getRadius() >= (*it)->getPosition().x + (*it)->getSize().x &&
								player.getPosition().y + player.getRadius() >= (*it)->getPosition().y &&
								player.getPosition().y - player.getRadius() <= (*it)->getPosition().y + (*it)->getSize().y)
							{
								if (player.velocity.x < 0)
								{
									player.accelerate(player.STOP);
									player.velocity.x = 0;
									player.setPosition((*it)->getPosition().x + (*it)->getSize().x + player.getRadius(), player.getPosition().y);
								}
							}
							else
								// Compenetration
								if ((*it)->getGlobalBounds().contains(player.getPosition()))
								{
									player.acceleration = Vector2f(0.f, 0.f);
									player.velocity = Vector2f(0.f, 0.f);
								}
			}
		}
	}
};




#endif