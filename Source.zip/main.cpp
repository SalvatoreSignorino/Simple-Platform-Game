#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Collectable.hpp"
#include "PlayerBall.hpp"
#include "LevelObject.hpp"
#include "Portal.hpp"

bool vSync = true;
bool fullscreen = true;

int main()
{
	// WINDOW CREATION
	sf::ContextSettings settings;
	settings.antialiasingLevel = 8;
	sf::RenderWindow window(sf::VideoMode(1366, 768), "", sf::Style::Fullscreen, settings);
	window.setVerticalSyncEnabled(vSync);
	window.setMouseCursorVisible(false);



	// LEVEL CREATION
	LevelObject* level = new LevelObject(1);
	SoundBuffer sBuffer;
	if (!sBuffer.loadFromFile("portal.wav")) 	std::cerr << "ERROR loading portal sound" << std::endl;
	Sound portalSound(sBuffer);



	// TIME HANDLERS CREATION
	sf::Clock frameClock;
	float deltaTime;	// In seconds.



	// GAME LOOP: run the program as long as the window is open
	while (window.isOpen())	
	{
		// TIME HANDLING
		deltaTime = frameClock.restart().asSeconds();
		


		// EVENTS HANDLING
		sf::Event event;	// check all the window's events that were triggered since the last iteration of the loop
		while (window.pollEvent(event)) 
		{
			switch (event.type) 
			{
				case sf::Event::Closed:
					window.close();
					break;
				case sf::Event::KeyPressed:
					if (event.key.code == sf::Keyboard::Key::Z)			level->changeColor(1);
					if (event.key.code == sf::Keyboard::Key::Numpad1)	level->changeColor(1);
					if (event.key.code == sf::Keyboard::Key::X)			level->changeColor(2);
					if (event.key.code == sf::Keyboard::Key::Numpad2)	level->changeColor(2);
					if (event.key.code == sf::Keyboard::Key::C)			level->changeColor(3);
					if (event.key.code == sf::Keyboard::Key::Numpad3)	level->changeColor(3);
					if (event.key.code == sf::Keyboard::Key::V)			// Toggle vertical sync.
					{
						if (vSync)
						{
							vSync = false;
							window.setVerticalSyncEnabled(vSync);
							window.setFramerateLimit(60);
						}
						else
						{
							vSync = true;
							window.setVerticalSyncEnabled(vSync);
						}
					}

					if (event.key.code == sf::Keyboard::Key::T)		// Toggle fullscreen
					{
						if (fullscreen)
						{
							fullscreen = false;
							window.create(sf::VideoMode(1366, 768), "", sf::Style::Default, settings);
						}
						else
						{
							fullscreen = true;
							window.create(sf::VideoMode(1366, 768), "", sf::Style::Fullscreen, settings);
						}
					}

					if (level->levelNum == 1 && event.key.code == sf::Keyboard::Key::N)	// Debug
					{
						level->clear();
						level = new LevelObject(2);
					}

					if (event.key.code == sf::Keyboard::Key::P)	// Debug
					{
						for (std::vector<Collectable>::iterator it = level->collectables.begin(); level->collectables.size() > 0 && it != level->collectables.end(); it++)
						{
							level->collectables.erase(it);
							it--;
							level->player.collect();
							if (level->player.collected == 10) level->portal->setTextureRect(IntRect(0, 0, 26, 32));
						}
					}	

					break;
				case sf::Event::KeyReleased:
					if (event.key.code == sf::Keyboard::Key::Escape)	window.close();
					if (event.key.code == sf::Keyboard::Key::Left)		level->player.accelerate(level->player.STOP);
					if (event.key.code == sf::Keyboard::Key::A)			level->player.accelerate(level->player.STOP);
					if (event.key.code == sf::Keyboard::Key::Right)		level->player.accelerate(level->player.STOP);
					if (event.key.code == sf::Keyboard::Key::D)			level->player.accelerate(level->player.STOP);
					break;
				default:
					break;
			}
		}



		// MOVEMENT INPUTS
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))	level->player.accelerate(level->player.RIGHT);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))		level->player.accelerate(level->player.RIGHT);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))		level->player.accelerate(level->player.LEFT);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))		level->player.accelerate(level->player.LEFT);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))	level->player.accelerate(level->player.JUMP);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))		level->player.accelerate(level->player.JUMP);
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))		level->player.accelerate(level->player.JUMP);



		// UPDATE LOGIC
		level->update(deltaTime, window.getSize());



		// Hitting the portal.
		if (level->player.collected == 10 && level->player.getGlobalBounds().intersects(level->portal->getGlobalBounds()))
		{
			portalSound.play();
			if (level->levelNum == 1)
			{
				level->clear();
				level = new LevelObject(2);
			}
			else if (level->levelNum == 2)
			{
				window.close();
			}
		}



		// REFRESHING WINDOW
		window.clear(sf::Color::Black);
		level->draw(window);
		window.display();
	}

	return 0;
}